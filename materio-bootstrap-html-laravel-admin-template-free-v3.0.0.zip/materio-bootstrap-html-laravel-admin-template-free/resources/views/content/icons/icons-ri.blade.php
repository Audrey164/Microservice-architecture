@extends('layouts/contentNavbarLayout')

@section('title', 'Remix - Icons')

@section('page-style')
@vite( 'resources/assets/vendor/scss/pages/page-icons.scss')
@endsection

@section('content')
<p>You can check complete list of Remix Icons from <a href="https://icon-sets.iconify.design/ri/" target="_blank">https://icon-sets.iconify.design/ri</a></p>

<!-- Icon Container -->
<div class="d-flex flex-wrap" id="icons-container">
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-arrow-left-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">Arrow left</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-arrow-right-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">Arrow right</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-home-4-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">home</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-home-gear-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">home gear</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-mail-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">Mail</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-mail-open-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">open mail</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-brush-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">Brush</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-palette-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">palette</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-line-chart-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">chart</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-pie-chart-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">pie chart</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-chat-4-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">chat</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-message-2-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">message proccessing</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-bold icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">bold</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-italic icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">Italic</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-html5-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">html 5</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-code-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">code</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-wifi-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">wifi</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-signal-wifi-error-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">signal error</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-mac-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">mac</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-save-3-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">save</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-volume-up-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">volume up</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-volume-mute-line icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">volume mute</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-linkedin-box-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">linkedin</p>
        </div>
    </div>
    <div class="card icon-card cursor-pointer text-center mb-6 mx-3">
        <div class="card-body">
            <i class="icon-base ri ri-twitter-fill icon-36px"></i>
            <p class="icon-name text-capitalize text-truncate mb-0 mt-2">twitter</p>
        </div>
    </div>
</div>

<!-- Buttons -->
<div class="d-flex justify-content-center mx-auto gap-4">
    <a href="https://icon-sets.iconify.design/ri/" target="_blank" class="btn btn-primary">View All Icons</a>
    <a href="{{config('variables.documentation')}}/Icons.html" class="btn btn-primary" target="_blank">How to use icons?</a>
</div>
@endsection
